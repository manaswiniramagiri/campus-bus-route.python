# Campus Bus Route Helper

Store campus bus routes and stops, find buses by stop name, and keep an eye on service.
Hackathon project #28 (Campus Catalyst brief). The core and the terminal app use only the
Python standard library. The Streamlit GUI is optional.

## Quick start

```bash
cd campus_bus_helper
python app.py                      # terminal app, no installs needed (Python 3.10+)
```

Optional GUI:

```bash
python -m venv .venv
source .venv/bin/activate          # Windows: .venv\Scripts\activate
pip install -r requirements.txt    # installs streamlit
streamlit run gui_streamlit.py
```

Run the tests: `python -m unittest discover -s tests -v`

A seeded `data/routes.json` (40 stop records on 10 routes) ships with the project, so there is
something to search the first time you launch. Delete it and the app creates a clean one.

## What each requirement maps to

| Brief requirement | Where it lives |
|---|---|
| Interactive terminal interface | `app.py`: branded welcome, numbered menu, tables, pagination |
| Defensive input validation | `core/validation.py`: one validator per field, plus `prompt_until_valid`, a loop that re-asks until the answer is valid |
| Core logic: store routes and stops, search routes by stop name | `core/logic.py` (`RouteBook.add`, `update`, `delete`, `search_stops`, `next_arrival`) |
| Local data persistence | `core/storage.py`: JSON, saved after every change, atomic writes, backs up and resets a damaged file |
| Record query and search | Keyword plus stop type, status and route filters (`filter_entries`); stop-name search is partial and case-insensitive, with "did you mean" |
| Executive summary | `core/analytics.py` (`summarize`): totals, averages, status and type breakdowns, busiest stops, buses per hour, plain-language trends |
| Multi-format export | `core/exporter.py`: Markdown summary, plain-text audit log, CSV route report, records CSV, optional PNG chart (needs matplotlib) |
| Threshold warnings | `analytics.warnings`: suspended, delayed, wait over 30 min, 5 seats or fewer, first bus outside 05:30-22:00, gaps in stop numbers |
| GUI | `gui_streamlit.py`: Dashboard, Find a bus, Add a stop, Manage stops, Import CSV, Export reports |
| Bulk dataset import | `core/importer.py`: row-by-row validation, imported vs rejected counts, error log (text in the terminal, CSV download in the GUI) |

## Data model

One record is one stop on one route.

| Field | Rule |
|---|---|
| `route_id` | 1-2 letters then 1-3 digits (R5, EX12). Stored upper case |
| `route_name` | 3-40 characters. All stops on a route share one name |
| `stop_name` | 2-40 characters, tidied to Title Case when typed all lower or all upper |
| `stop_order` | Whole number 1-50, unique within the route |
| `arrival_time` | 24-hour HH:MM, the first bus at this stop |
| `frequency_min` | Whole number 1-120, minutes between buses |
| `capacity` | Whole number 1-200, seats per bus |
| `status` | Active, Delayed or Suspended |
| `category` | Hostel, Academic, Admin, Sports or Gate |

Buses at a stop run from `arrival_time` every `frequency_min` minutes until the last bus at 22:00.
That is how "next bus" is worked out. Limits and service hours are constants at the top of `core/models.py`.

## Five-minute demo script

1. **Launch.** `python app.py` shows the welcome screen and menu.
2. **Validation.** Choose 1 (Add a stop). Type `5` as the route ID, leave the route name blank, type
   `8:5` as the time, `0` as the wait and `500` as the seats. Each is caught and re-asked. Then enter good values.
3. **Search.** Choose 2 and type `lib`. You get every route through Library with the next bus time.
   Try `libary` in the GUI to see the "did you mean" hint.
4. **Analytics.** Choose 7 for the summary and 8 for warnings.
5. **Persistence.** Choose 0, run `python app.py` again, and search for the stop you added.
6. **Import.** Choose 10 and press Enter to use `data/sample_import_with_errors.csv`: 6 rows import, 10 are
   rejected with reasons, and a log is written to `exports/`.
7. **Export.** Choose 9, then 1, and open the files in `exports/`.
8. **GUI.** `streamlit run gui_streamlit.py` shows the same data as route lines, charts and metrics.

## Sample data

| File | What it is |
|---|---|
| `data/routes.json` | Live data file the apps read and write |
| `data/sample_routes.csv` / `.json` | The same 40 records. Option 11 in the terminal (or "Add the sample network" in the GUI) reloads them |
| `data/sample_import_with_errors.csv` | 16 rows for the import demo: 6 valid (including odd casing and stray spaces that get cleaned) and 10 invalid (zero wait, 500 seats, bad time, blank stop, bad status, text for a number, unknown type, duplicate stop, short row, long row) |

The sample covers boundary values (wait of 1 and 120 minutes, 1 and 200 seats), a delayed route,
a suspended route, and stops shared by several routes (Main Gate is on 6 routes).

## If something goes wrong

- **Damaged `routes.json`:** the app keeps a copy named `routes.corrupt-<time>.bak`, starts a clean file and says so on launch.
- **Colours look odd in the terminal:** set `NO_COLOR=1` for plain text.
- **GUI fonts:** they load from Google Fonts. Offline, the GUI falls back to system fonts.

## Layout

```
app.py              terminal app
gui_streamlit.py    Streamlit GUI
core/               models, validation, storage, logic, analytics, importer, exporter
data/               live data, samples
exports/            generated reports (created on demand)
tests/test_core.py  25 tests
.streamlit/         GUI theme
```
