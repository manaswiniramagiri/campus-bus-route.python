#!/usr/bin/env python3
"""Campus Bus Route Helper: terminal interface.

Run:  python app.py            (use --data FILE for a different data file)
"""
from __future__ import annotations

import argparse
import os
import sys
from datetime import datetime
from pathlib import Path

from core import analytics, exporter, importer
from core import validation as V
from core.logic import RouteBook, describe_next
from core.models import CATEGORIES, FIELDS, STATUSES, SERVICE_END, to_minutes, worst_status

BASE = Path(__file__).resolve().parent
DATA_FILE = BASE / "data" / "routes.json"
EXPORT_DIR = BASE / "exports"
SAMPLE_CSV = BASE / "data" / "sample_routes.csv"
SAMPLE_BAD_CSV = BASE / "data" / "sample_import_with_errors.csv"

# ---------------------------------------------------------------- styling
USE_COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR")
if USE_COLOR and os.name == "nt":
    os.system("")  # switches on ANSI escape handling in Windows terminals

CODES = {"bold": "1", "dim": "2", "teal": "38;5;37", "amber": "38;5;214",
         "red": "38;5;167", "blue": "38;5;75"}
STATUS_COLOR = {"Active": "teal", "Delayed": "amber", "Suspended": "red"}
LEVEL_COLOR = {"critical": "red", "warning": "amber", "info": "blue"}


def paint(text, *styles) -> str:
    if not USE_COLOR or not styles:
        return str(text)
    return f"\033[{';'.join(CODES[s] for s in styles)}m{text}\033[0m"


def say(text="", *styles):
    print(paint(text, *styles))


def header(title: str):
    say()
    say(f"  {title}", "bold", "teal")
    say("  " + "─" * (len(title) + 2), "dim")


def banner():
    line = paint("●", "teal") + (paint("━━━━━", "teal") + paint("●", "teal")) * 3 \
        + paint("━━━━━", "teal") + paint("●", "amber")
    say()
    print("   " + line)
    say("   Campus Bus Route Helper", "bold")
    say("   Store routes and stops, find buses by stop name, keep service on track.", "dim")
    say()


# ---------------------------------------------------------------- tables
def _cell(value, width, align="l"):
    text = str(value)
    if len(text) > width:
        text = text[: width - 1] + "…"
    return text.ljust(width) if align == "l" else text.rjust(width)


def render_table(rows, cols):
    """cols: (header, width, getter, align[, colour_fn])."""
    head = "  ".join(_cell(c[0], c[1], c[3]) for c in cols)
    say("  " + head, "bold")
    say("  " + "─" * len(head), "dim")
    for row in rows:
        cells = []
        for c in cols:
            cell = _cell(c[2](row), c[1], c[3])
            style = c[4](row) if len(c) > 4 else None
            cells.append(paint(cell, style) if style else cell)
        print("  " + "  ".join(cells))


def paged(rows, cols, size=10):
    if not rows:
        say("  Nothing matches.", "amber")
        return
    for start in range(0, len(rows), size):
        chunk = rows[start:start + size]
        render_table(chunk, cols)
        end = start + len(chunk)
        say(f"  Showing {start + 1}-{end} of {len(rows)}", "dim")
        if end < len(rows) and input("  Enter for the next page, q to stop: ").strip().lower().startswith("q"):
            break


def status_style(e):
    return STATUS_COLOR[e.status]


ENTRY_COLS = [
    ("Route", 5, lambda e: e.route_id, "l"),
    ("Route name", 24, lambda e: e.route_name, "l"),
    ("#", 3, lambda e: e.stop_order, "r"),
    ("Stop", 20, lambda e: e.stop_name, "l"),
    ("Type", 8, lambda e: e.category, "l"),
    ("First", 5, lambda e: e.arrival_time, "l"),
    ("Every", 5, lambda e: f"{e.frequency_min}m", "r"),
    ("Seats", 5, lambda e: e.capacity, "r"),
    ("Status", 9, lambda e: e.status, "l", status_style),
]


# ---------------------------------------------------------------- input
def ask(prompt, validator, default=None):
    return V.prompt_until_valid(prompt, validator, default, input_fn=input,
                                on_error=lambda m: say(f"  ✗ {m}", "red"))


def ask_choice(prompt, options, allow_any=False, blank_hint="blank for any"):
    shown = "  ".join(f"{i}) {o}" for i, o in enumerate(options, 1))
    say(f"  {shown}", "dim")
    while True:
        raw = input(f"  {prompt}{f' ({blank_hint})' if allow_any else ''}: ").strip()
        if allow_any and not raw:
            return None
        try:
            return V.make_choice_validator(options, "Choice")(raw)
        except V.ValidationError as exc:
            say(f"  ✗ {exc}", "red")


def ask_yes_no(prompt, default=False):
    hint = "Y/n" if default else "y/N"
    while True:
        raw = input(f"  {prompt} ({hint}): ").strip().lower()
        if not raw:
            return default
        if raw in ("y", "yes"):
            return True
        if raw in ("n", "no"):
            return False
        say("  ✗ Please answer y or n.", "red")


def optional(validator):
    """Blank means 'no filter' / 'no value'."""
    return lambda v: None if V.clean(v) == "" else validator(v)


def now_minutes() -> int:
    n = datetime.now()
    return n.hour * 60 + n.minute


def show_errors(exc: V.ValidationError):
    for message in (exc.errors.values() if exc.errors else [str(exc)]):
        say(f"  ✗ {message}", "red")
    say("  Nothing was saved.", "dim")


# ---------------------------------------------------------------- screens
def add_entry(book: RouteBook):
    header("Add a stop to a route")
    route_id = ask("Route ID (like R5)", V.v_route_id)
    existing = book.routes().get(route_id)
    default_name = None
    if existing:
        default_name = existing[0].route_name
        say(f"  {route_id} already exists as \"{default_name}\" with {len(existing)} stop(s).", "dim")
    route_name = ask("Route name", V.v_route_name, default_name)
    stop_name = ask("Stop name", V.v_stop_name)
    next_order = max((e.stop_order for e in existing), default=0) + 1 if existing else 1
    stop_order = ask("Stop number on the route", V.v_order, next_order)
    arrival = ask("First bus at this stop (HH:MM, 24-hour)", V.v_time)
    freq = ask("Minutes between buses (1-120)", V.v_frequency)
    cap = ask("Seats per bus (1-200)", V.v_capacity)
    say("  Status:", "dim")
    status = ask_choice("Status", STATUSES)
    say("  Stop type:", "dim")
    category = ask_choice("Stop type", CATEGORIES)
    raw = dict(route_id=route_id, route_name=route_name, stop_name=stop_name, stop_order=stop_order,
               arrival_time=arrival, frequency_min=freq, capacity=cap, status=status, category=category)
    try:
        entry = book.add(raw)
    except V.ValidationError as exc:
        show_errors(exc)
        return
    say(f"  ✓ Saved {entry.stop_name} as stop {entry.stop_order} on {entry.route_id}.", "teal")


def search_by_stop(book: RouteBook):
    header("Find buses by stop name")
    query = ask("Stop name (part of a name is fine)", V.v_stop_name)
    matches = book.search_stops(query)
    if not matches:
        say(f"  No stop matches \"{query}\".", "amber")
        close = book.suggest_stops(query)
        if close:
            say("  Did you mean: " + ", ".join(close) + "?")
        return
    now = now_minutes()
    say(f"  Next buses are worked out from {datetime.now():%H:%M} (last bus {SERVICE_END}).", "dim")
    cols = [
        ("Route", 5, lambda e: e.route_id, "l"),
        ("Route name", 24, lambda e: e.route_name, "l"),
        ("Stop #", 6, lambda e: e.stop_order, "r"),
        ("First", 5, lambda e: e.arrival_time, "l"),
        ("Every", 5, lambda e: f"{e.frequency_min}m", "r"),
        ("Next bus", 20, lambda e: describe_next(e, now), "l"),
        ("Status", 9, lambda e: e.status, "l", status_style),
    ]
    for match in matches:
        say()
        say(f"  {match.name}", "bold")
        say(f"  {match.category} stop, served by {len(match.entries)} route(s)", "dim")
        render_table(match.entries, cols)


def browse(book: RouteBook):
    header("Browse and filter records")
    keyword = ask("Keyword in route or stop name (blank for all)", optional(V.clean))
    say("  Stop type:", "dim")
    category = ask_choice("Stop type", CATEGORIES, allow_any=True)
    say("  Status:", "dim")
    status = ask_choice("Status", STATUSES, allow_any=True)
    route_id = ask("Route ID (blank for all)", optional(V.v_route_id))
    rows = book.filter_entries(keyword, category, status, route_id)
    say()
    paged(rows, ENTRY_COLS)


def view_route(book: RouteBook):
    header("View a route")
    routes = book.routes()
    if not routes:
        say("  No routes yet.", "amber")
        return
    say("  Routes: " + ", ".join(routes), "dim")
    route_id = ask("Route ID", V.v_route_id)
    stops = routes.get(route_id)
    if not stops:
        say(f"  There is no route {route_id}.", "amber")
        return
    status = worst_status(stops)
    say()
    say(f"  {route_id}  {stops[0].route_name}  [{status}]", "bold", STATUS_COLOR[status])
    for i, e in enumerate(stops):
        dot = paint("●", STATUS_COLOR[e.status])
        print(f"   {dot} {e.arrival_time}  {e.stop_name}  " + paint(f"({e.category}, every {e.frequency_min} min, "
                                                                    f"{e.capacity} seats)", "dim"))
        if i < len(stops) - 1:
            say("   ┃", "teal")


def _pick_entry(book: RouteBook):
    route_id = ask("Route ID", V.v_route_id)
    stops = book.routes().get(route_id)
    if not stops:
        say(f"  There is no route {route_id}.", "amber")
        return None
    render_table(stops, ENTRY_COLS)
    order = ask("Stop number", V.v_order)
    entry = book.get(route_id, order)
    if entry is None:
        say(f"  There is no stop {order} on {route_id}.", "amber")
    return entry


def edit_entry(book: RouteBook):
    header("Edit a stop (press Enter to keep the current value)")
    entry = _pick_entry(book)
    if entry is None:
        return
    changes = {
        "route_name": ask("Route name", V.v_route_name, entry.route_name),
        "stop_name": ask("Stop name", V.v_stop_name, entry.stop_name),
        "stop_order": ask("Stop number", V.v_order, entry.stop_order),
        "arrival_time": ask("First bus (HH:MM)", V.v_time, entry.arrival_time),
        "frequency_min": ask("Minutes between buses", V.v_frequency, entry.frequency_min),
        "capacity": ask("Seats per bus", V.v_capacity, entry.capacity),
    }
    say("  Status:", "dim")
    changes["status"] = ask_choice("Status", STATUSES, allow_any=True, blank_hint="Enter to keep") or entry.status
    say("  Stop type:", "dim")
    changes["category"] = ask_choice("Stop type", CATEGORIES, allow_any=True, blank_hint="Enter to keep") or entry.category
    try:
        book.update(entry.route_id, entry.stop_order, changes)
    except V.ValidationError as exc:
        show_errors(exc)
        return
    say("  ✓ Changes saved.", "teal")


def delete_entry(book: RouteBook):
    header("Delete a stop")
    entry = _pick_entry(book)
    if entry is None:
        return
    if ask_yes_no(f"Delete {entry.stop_name} (stop {entry.stop_order}) from {entry.route_id}?"):
        book.delete(entry.route_id, entry.stop_order)
        say("  ✓ Deleted.", "teal")
    else:
        say("  Kept. Nothing changed.", "dim")


def _bar(value, top, width=26):
    return "█" * (round(width * value / top) if top else 0)


def summary(book: RouteBook):
    header("Executive summary")
    s = analytics.summarize(book.entries)
    if s["empty"]:
        say("  No records yet. Add a stop or load the sample data.", "amber")
        return
    render_table([
        ("Routes", s["total_routes"]), ("Stop records", s["total_entries"]),
        ("Unique stops", s["unique_stops"]),
        ("Average wait between buses", f"{s['avg_frequency']} min "
                                       f"(shortest {s['min_frequency']}, longest {s['max_frequency']})"),
        ("Average seats per bus", s["avg_capacity"]), ("Total seats on one pass", s["total_capacity"]),
        ("First bus of the day", s["earliest_bus"]), ("Running normally", f"{s['active_pct']}%"),
    ], [("Measure", 28, lambda r: r[0], "l"), ("Value", 44, lambda r: r[1], "l")])

    say("\n  Status of stop records", "bold")
    top = max(s["status_counts"].values())
    for name, n in s["status_counts"].items():
        say(f"  {name:10}{n:>4}  " + paint(_bar(n, top), STATUS_COLOR[name]))

    say("\n  Average wait by stop type", "bold")
    top = max(s["avg_frequency_by_category"].values())
    for name, v in s["avg_frequency_by_category"].items():
        say(f"  {name:10}{v:>6} min  " + paint(_bar(v, top), "teal"))

    say("\n  Best-connected stops", "bold")
    render_table(s["busiest_stops"], [("Stop", 24, lambda r: r[0], "l"), ("Routes", 6, lambda r: r[1], "r")])

    say("\n  Longest routes", "bold")
    render_table(s["longest_routes"], [("Route", 5, lambda r: r[0], "l"), ("Name", 28, lambda r: r[1], "l"),
                                       ("Stops", 5, lambda r: r[2], "r")])

    say("\n  Bus arrivals per hour (all stops)", "bold")
    top = max(s["buses_per_hour"].values())
    for hour, n in s["buses_per_hour"].items():
        say(f"  {hour}  {n:>4}  " + paint(_bar(n, top), "blue"))

    say("\n  Trends", "bold")
    for line in s["trends"]:
        say(f"  • {line}")
    alerts = analytics.warnings(book.entries)
    say(f"\n  {len(alerts)} warning(s). Choose option 8 to see them.",
        "amber" if alerts else "teal")


def show_warnings(book: RouteBook):
    header("Warnings")
    alerts = analytics.warnings(book.entries)
    if not alerts:
        say("  All clear. Nothing is over a threshold.", "teal")
        return
    counts = {lvl: sum(a.level == lvl for a in alerts) for lvl in LEVEL_COLOR}
    say(f"  {counts['critical']} critical, {counts['warning']} warning, {counts['info']} info", "dim")
    for a in alerts:
        say(f"  {'▲' if a.level != 'info' else '•'} {a.level:8} {a.message}", LEVEL_COLOR[a.level])


def export_reports(book: RouteBook):
    header("Export reports")
    if not book.entries:
        say("  Nothing to export yet.", "amber")
        return
    options = ["All text formats", "Markdown summary", "Plain-text audit log", "CSV report",
               "PNG chart (needs matplotlib)"]
    choice = ask_choice("Export", options)
    paths = exporter.export_all(book.entries, EXPORT_DIR)
    if choice == options[0]:
        chosen = list(paths.values())
    elif choice == options[4]:
        chart = exporter.export_chart(book.entries, EXPORT_DIR)
        chosen = [chart] if chart else []
        if not chart:
            say("  matplotlib isn't installed. Run: pip install matplotlib", "amber")
    else:
        wanted = {options[1]: "Markdown summary", options[2]: "Audit log", options[3]: "CSV report"}[choice]
        chosen = [paths[wanted]]
        for label, path in paths.items():  # keep only what was asked for
            if label not in (wanted,):
                path.unlink(missing_ok=True)
    for path in chosen:
        say(f"  ✓ {path.relative_to(BASE) if BASE in path.parents else path}", "teal")


def bulk_import(book: RouteBook):
    header("Bulk import from CSV")
    say("  Columns needed: " + ", ".join(FIELDS), "dim")
    say(f"  Try the demo file: {SAMPLE_BAD_CSV.relative_to(BASE)}", "dim")
    raw = ask("Path to CSV file", V.clean, str(SAMPLE_BAD_CSV.relative_to(BASE)))
    path = Path(raw).expanduser()
    if not path.is_absolute() and not path.exists():
        path = BASE / path
    result = importer.import_csv_file(book, path)
    if result.fatal:
        say(f"  ✗ {result.fatal}", "red")
        return
    say(f"\n  Read {result.total} row(s): {result.imported} imported, {result.rejected} rejected.",
        "teal" if not result.rejected else "amber")
    if result.errors:
        render_table(result.errors[:15], [("Row", 4, lambda r: r.row, "r"),
                                          ("Why it was rejected", 76, lambda r: r.reason, "l")])
        if len(result.errors) > 15:
            say(f"  …and {len(result.errors) - 15} more in the log.", "dim")
        log = importer.write_error_log(result, EXPORT_DIR)
        say(f"  Full error log: {log.relative_to(BASE) if BASE in log.parents else log}", "dim")


def load_sample(book: RouteBook):
    header("Load sample data")
    say(f"  {len(book.entries)} record(s) loaded right now.", "dim")
    mode = ask_choice("Choose", ["Add the sample records to what I have", "Replace everything with the sample"])
    if mode.startswith("Replace"):
        if not ask_yes_no("This deletes your current records. Continue?"):
            say("  Kept. Nothing changed.", "dim")
            return
        book.clear()
    result = importer.import_csv_file(book, SAMPLE_CSV)
    say(f"  ✓ {result.imported} sample record(s) added, {result.rejected} skipped as duplicates.", "teal")


MENU = [
    ("1", "Add a stop to a route", add_entry),
    ("2", "Find buses by stop name", search_by_stop),
    ("3", "Browse and filter records", browse),
    ("4", "View a route", view_route),
    ("5", "Edit a stop", edit_entry),
    ("6", "Delete a stop", delete_entry),
    ("7", "Executive summary", summary),
    ("8", "Warnings", show_warnings),
    ("9", "Export reports", export_reports),
    ("10", "Bulk import from CSV", bulk_import),
    ("11", "Load sample data", load_sample),
    ("0", "Exit", None),
]


def main(argv=None) -> int:
    parser = argparse.ArgumentParser(description="Campus Bus Route Helper")
    parser.add_argument("--data", default=str(DATA_FILE), help="path to the JSON data file")
    args = parser.parse_args(argv)

    book = RouteBook(args.data)
    banner()
    for note in book.notes:
        say(f"  ! {note}", "amber")
    say(f"  {len(book.entries)} stop record(s) on {len(book.routes())} route(s) loaded.", "dim")

    actions = {key: fn for key, _, fn in MENU}
    while True:
        say()
        for key, label, _ in MENU:
            print(f"  {paint(key.rjust(2), 'teal', 'bold')}  {label}")
        try:
            choice = input("\n  Choose an option: ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            break
        if choice in ("0", "q", "quit", "exit"):
            break
        if choice not in actions:
            say(f"  ✗ '{choice}' isn't on the menu. Type a number from 0 to 11.", "red")
            continue
        try:
            actions[choice](book)
        except KeyboardInterrupt:
            say("\n  Cancelled.", "dim")
        except EOFError:
            break
        if sys.stdin.isatty():
            input(paint("\n  Press Enter to return to the menu…", "dim"))
    say("\n  Your data is saved. See you next time.\n", "teal")
    return 0


if __name__ == "__main__":
    sys.exit(main())
