"""Campus Bus Route Helper: framework-free core shared by the CLI and the GUI."""
