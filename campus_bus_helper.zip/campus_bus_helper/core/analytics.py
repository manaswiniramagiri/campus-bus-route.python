"""Executive summary, trends and threshold warnings."""
from __future__ import annotations

from collections import Counter
from dataclasses import dataclass
from statistics import mean

from .models import (CATEGORIES, HIGH_CAPACITY, LONG_WAIT_MIN, LOW_CAPACITY, SERVICE_END,
                     SERVICE_START, STATUSES, group_routes, to_minutes)


@dataclass
class Alert:
    level: str          # critical | warning | info
    code: str
    message: str
    route_id: str = ""
    stop_name: str = ""


def arrivals_by_hour(entry) -> Counter:
    """How many buses reach this stop in each hour of the day."""
    first = entry.first_minutes
    last = max(to_minutes(SERVICE_END), first)
    counts, t = Counter(), first
    while t <= last:
        counts[t // 60] += 1
        t += entry.frequency_min
    return counts


def summarize(entries) -> dict:
    entries = list(entries)
    if not entries:
        return {"empty": True, "total_entries": 0, "total_routes": 0, "unique_stops": 0}

    routes = group_routes(entries)
    stop_routes: dict = {}
    for e in entries:
        stop_routes.setdefault(e.stop_name, set()).add(e.route_id)
    busiest_stops = sorted(((n, len(r)) for n, r in stop_routes.items()),
                           key=lambda x: (-x[1], x[0]))[:5]
    longest_routes = sorted(((rid, stops[0].route_name, len(stops)) for rid, stops in routes.items()),
                            key=lambda x: (-x[2], x[0]))[:5]

    statuses = Counter(e.status for e in entries)
    categories = Counter(e.category for e in entries)
    freq_by_cat = {c: round(mean(e.frequency_min for e in entries if e.category == c), 1)
                   for c in CATEGORIES if categories[c]}

    hourly = Counter()
    for e in entries:
        if e.status != "Suspended":
            hourly.update(arrivals_by_hour(e))
    lo = min([5, *hourly]) if hourly else 5
    hi = max([22, *hourly]) if hourly else 22
    buses_per_hour = {f"{h:02d}:00": hourly.get(h, 0) for h in range(lo, hi + 1)}
    peak_hour, peak_count = max(buses_per_hour.items(), key=lambda kv: kv[1])

    active_pct = round(100 * statuses["Active"] / len(entries))
    trends = []
    trends.append(f"Service peaks at {peak_hour} with {peak_count} bus arrivals across all stops.")
    if busiest_stops:
        name, count = busiest_stops[0]
        trends.append(f"{name} is the best-connected stop, served by {count} route"
                      f"{'s' if count != 1 else ''}.")
    if freq_by_cat:
        fastest = min(freq_by_cat, key=freq_by_cat.get)
        slowest = max(freq_by_cat, key=freq_by_cat.get)
        trends.append(f"{fastest} stops get the shortest average wait ({freq_by_cat[fastest]} min); "
                      f"{slowest} stops the longest ({freq_by_cat[slowest]} min).")
    trends.append(f"{active_pct}% of stop records are running normally.")
    if statuses["Suspended"] or statuses["Delayed"]:
        trends.append(f"{statuses['Suspended']} suspended and {statuses['Delayed']} delayed "
                      "stop record(s) need attention.")

    return {
        "empty": False,
        "total_entries": len(entries),
        "total_routes": len(routes),
        "unique_stops": len(stop_routes),
        "avg_frequency": round(mean(e.frequency_min for e in entries), 1),
        "min_frequency": min(e.frequency_min for e in entries),
        "max_frequency": max(e.frequency_min for e in entries),
        "avg_capacity": round(mean(e.capacity for e in entries), 1),
        "total_capacity": sum(e.capacity for e in entries),
        "earliest_bus": min(e.arrival_time for e in entries),
        "latest_first_bus": max(e.arrival_time for e in entries),
        "status_counts": {s: statuses.get(s, 0) for s in STATUSES},
        "category_counts": {c: categories.get(c, 0) for c in CATEGORIES},
        "avg_frequency_by_category": freq_by_cat,
        "busiest_stops": busiest_stops,
        "longest_routes": longest_routes,
        "buses_per_hour": buses_per_hour,
        "peak_hour": (peak_hour, peak_count),
        "active_pct": active_pct,
        "trends": trends,
    }


def warnings(entries) -> list:
    """Threshold flags: delays, suspensions, long waits, odd capacities, odd hours, gaps."""
    alerts = []
    for e in entries:
        where = f"{e.stop_name} on {e.route_id}"
        if e.status == "Suspended":
            alerts.append(Alert("critical", "SUSPENDED", f"{where} is suspended.", e.route_id, e.stop_name))
        elif e.status == "Delayed":
            alerts.append(Alert("warning", "DELAYED", f"{where} is running delayed.", e.route_id, e.stop_name))
        if e.frequency_min > LONG_WAIT_MIN:
            alerts.append(Alert("warning", "LONG_WAIT",
                                f"{where}: buses come every {e.frequency_min} min (over {LONG_WAIT_MIN}).",
                                e.route_id, e.stop_name))
        if e.capacity <= LOW_CAPACITY:
            alerts.append(Alert("warning", "LOW_CAPACITY",
                                f"{where}: only {e.capacity} seat(s) per bus.", e.route_id, e.stop_name))
        elif e.capacity >= HIGH_CAPACITY:
            alerts.append(Alert("info", "HIGH_CAPACITY",
                                f"{where}: unusually large vehicle ({e.capacity} seats).",
                                e.route_id, e.stop_name))
        if e.arrival_time < SERVICE_START or e.arrival_time > SERVICE_END:
            alerts.append(Alert("warning", "ODD_HOURS",
                                f"{where}: first bus at {e.arrival_time} is outside "
                                f"{SERVICE_START}-{SERVICE_END}.", e.route_id, e.stop_name))
    for rid, stops in group_routes(entries).items():
        orders = [s.stop_order for s in stops]
        missing = [n for n in range(orders[0], orders[-1] + 1) if n not in orders]
        if missing:
            alerts.append(Alert("warning", "ORDER_GAP",
                                f"{rid} skips stop number(s) {', '.join(map(str, missing))}.", rid))
        if len(stops) == 1:
            alerts.append(Alert("info", "SINGLE_STOP", f"{rid} has only one stop so far.", rid))
    rank = {"critical": 0, "warning": 1, "info": 2}
    return sorted(alerts, key=lambda a: (rank[a.level], a.route_id, a.stop_name))
