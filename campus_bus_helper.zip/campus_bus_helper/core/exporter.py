"""Markdown summary, plain-text audit log, CSV report, optional chart."""
from __future__ import annotations

import csv
import io
import time
from pathlib import Path

from . import analytics
from .models import FIELDS, group_routes, route_sort_key, worst_status


def _stamp() -> str:
    return time.strftime("%Y-%m-%d %H:%M")


def render_markdown(entries, generated: str | None = None) -> str:
    entries = list(entries)
    s = analytics.summarize(entries)
    out = ["# Campus Bus Route Helper: Service Summary", "", f"Generated {generated or _stamp()}", ""]
    if s["empty"]:
        return "\n".join(out + ["No records yet."]) + "\n"
    out += ["## Overview", "", "| Measure | Value |", "|---|---|",
            f"| Routes | {s['total_routes']} |", f"| Stop records | {s['total_entries']} |",
            f"| Unique stops | {s['unique_stops']} |",
            f"| Average wait between buses | {s['avg_frequency']} min |",
            f"| Average seats per bus | {s['avg_capacity']} |",
            f"| Running normally | {s['active_pct']}% |", ""]
    out += ["## Status", "", "| Status | Stop records |", "|---|---|"]
    out += [f"| {k} | {v} |" for k, v in s["status_counts"].items()] + [""]
    out += ["## Busiest stops", "", "| Stop | Routes serving it |", "|---|---|"]
    out += [f"| {n} | {c} |" for n, c in s["busiest_stops"]] + [""]
    out += ["## Trends", ""] + [f"- {t}" for t in s["trends"]] + [""]
    out += ["## Routes", ""]
    for rid, stops in group_routes(entries).items():
        out += [f"### {rid}: {stops[0].route_name} ({worst_status(stops)})", "",
                "| # | Stop | Type | First bus | Every | Seats | Status |", "|---|---|---|---|---|---|---|"]
        out += [f"| {e.stop_order} | {e.stop_name} | {e.category} | {e.arrival_time} | "
                f"{e.frequency_min} min | {e.capacity} | {e.status} |" for e in stops] + [""]
    alerts = analytics.warnings(entries)
    out += ["## Warnings", ""]
    out += [f"- **{a.level}**: {a.message}" for a in alerts] if alerts else ["No warnings."]
    return "\n".join(out) + "\n"


def render_audit_log(entries, generated: str | None = None) -> str:
    entries = list(entries)
    s = analytics.summarize(entries)
    lines = ["CAMPUS BUS ROUTE HELPER - AUDIT LOG", f"Generated: {generated or _stamp()}",
             "=" * 72, ""]
    if s["empty"]:
        return "\n".join(lines + ["No records."]) + "\n"
    lines += ["SUMMARY",
              f"  Routes: {s['total_routes']}   Stop records: {s['total_entries']}   "
              f"Unique stops: {s['unique_stops']}",
              f"  Avg wait: {s['avg_frequency']} min   Avg seats: {s['avg_capacity']}   "
              f"Total seats: {s['total_capacity']}",
              "  Status: " + ", ".join(f"{k}={v}" for k, v in s["status_counts"].items()), "",
              "WARNINGS"]
    alerts = analytics.warnings(entries)
    lines += [f"  [{a.level.upper():8}] {a.message}" for a in alerts] or ["  None"]
    lines += ["", "RECORDS",
              f"  {'Route':6}{'Stop':26}{'#':>3}  {'First':6}{'Every':>6}{'Seats':>6}  {'Status':10}Type"]
    for e in sorted(entries, key=lambda e: (route_sort_key(e.route_id), e.stop_order)):
        lines.append(f"  {e.route_id:6}{e.stop_name[:25]:26}{e.stop_order:>3}  {e.arrival_time:6}"
                     f"{e.frequency_min:>6}{e.capacity:>6}  {e.status:10}{e.category}")
    lines += ["", "END OF LOG"]
    return "\n".join(lines) + "\n"


def render_csv_report(entries) -> str:
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["route_id", "route_name", "stops", "first_stop", "last_stop", "first_bus",
                     "avg_frequency_min", "total_seats", "status", "warnings"])
    alerts = analytics.warnings(entries)
    for rid, stops in group_routes(entries).items():
        writer.writerow([rid, stops[0].route_name, len(stops), stops[0].stop_name, stops[-1].stop_name,
                         min(s.arrival_time for s in stops),
                         round(sum(s.frequency_min for s in stops) / len(stops), 1),
                         sum(s.capacity for s in stops), worst_status(stops),
                         sum(1 for a in alerts if a.route_id == rid)])
    return buffer.getvalue()


def render_records_csv(entries) -> str:
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(FIELDS)
    for e in entries:
        writer.writerow([getattr(e, f) for f in FIELDS])
    return buffer.getvalue()


def export_all(entries, out_dir) -> dict:
    """Write every format into out_dir; returns {label: Path}."""
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    files = {
        "Markdown summary": (f"summary_{stamp}.md", render_markdown(entries)),
        "Audit log": (f"audit_log_{stamp}.txt", render_audit_log(entries)),
        "CSV report": (f"route_report_{stamp}.csv", render_csv_report(entries)),
        "Records CSV": (f"records_{stamp}.csv", render_records_csv(entries)),
    }
    paths = {}
    for label, (name, text) in files.items():
        path = out_dir / name
        path.write_text(text, encoding="utf-8", newline="")
        paths[label] = path
    return paths


def export_chart(entries, out_dir):
    """Optional Matplotlib chart. Returns a Path, or None if matplotlib isn't installed."""
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        return None
    s = analytics.summarize(entries)
    if s["empty"]:
        return None
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    fig, (a, b) = plt.subplots(1, 2, figsize=(11, 4), gridspec_kw={"width_ratios": [3, 1]})
    hours = s["buses_per_hour"]
    a.bar(list(hours), list(hours.values()), color="#0E8C7F")
    a.set_title("Bus arrivals per hour")
    a.tick_params(axis="x", rotation=60)
    st = s["status_counts"]
    b.bar(list(st), list(st.values()), color=["#0E8C7F", "#F4B400", "#D1495B"])
    b.set_title("Stop records by status")
    fig.tight_layout()
    path = out_dir / f"chart_{time.strftime('%Y%m%d-%H%M%S')}.png"
    fig.savefig(path, dpi=150)
    plt.close(fig)
    return path
