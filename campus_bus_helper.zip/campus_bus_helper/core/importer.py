"""Bulk CSV import with row-by-row error reporting."""
from __future__ import annotations

import csv
import io
import time
from dataclasses import dataclass, field
from pathlib import Path

from .models import FIELDS
from .validation import ValidationError


@dataclass
class RowError:
    row: int
    reason: str
    raw: dict


@dataclass
class ImportResult:
    source: str = "CSV"
    imported: int = 0
    errors: list = field(default_factory=list)
    fatal: str = ""

    @property
    def rejected(self) -> int:
        return len(self.errors)

    @property
    def total(self) -> int:
        return self.imported + self.rejected


def _header(name) -> str:
    return (name or "").strip().lstrip("\ufeff").lower().replace(" ", "_")


def import_csv_text(book, text: str, source: str = "CSV", save: bool = True) -> ImportResult:
    result = ImportResult(source=source)
    reader = csv.DictReader(io.StringIO(text))
    if not reader.fieldnames:
        result.fatal = "The file is empty."
        return result
    headers = [_header(h) for h in reader.fieldnames]
    missing = [f for f in FIELDS if f not in headers]
    if missing:
        result.fatal = ("Missing column(s): " + ", ".join(missing) +
                        ". Expected: " + ", ".join(FIELDS) + ".")
        return result
    reader.fieldnames = headers

    for row in reader:
        line = reader.line_num
        values = {k: v for k, v in row.items() if k is not None}
        if all(not (v or "").strip() for v in values.values()) and None not in row:
            continue  # blank line
        raw = {f: values.get(f) for f in FIELDS}
        if None in row:
            result.errors.append(RowError(line, "Row has more values than the header.", raw))
            continue
        if any(v is None for v in values.values()):
            result.errors.append(RowError(line, "Row has fewer values than the header.", raw))
            continue
        try:
            book.add(raw, save=False)
            result.imported += 1
        except ValidationError as exc:
            result.errors.append(RowError(line, " ".join(exc.errors.values()) or str(exc), raw))
    if result.imported and save:
        book.save()
    return result


def import_csv_file(book, path, save: bool = True) -> ImportResult:
    path = Path(path)
    try:
        text = path.read_text(encoding="utf-8-sig")
    except FileNotFoundError:
        return ImportResult(source=path.name, fatal=f"File not found: {path}")
    except UnicodeDecodeError:
        return ImportResult(source=path.name, fatal="The file isn't UTF-8 text. Save it as CSV (UTF-8).")
    return import_csv_text(book, text, source=path.name, save=save)


def render_error_log_text(result: ImportResult) -> str:
    lines = [f"Import log for {result.source}",
             f"Rows imported: {result.imported}   Rows rejected: {result.rejected}", ""]
    if result.fatal:
        lines.append(f"FAILED: {result.fatal}")
    for err in result.errors:
        lines.append(f"Row {err.row}: {err.reason}")
        lines.append("    " + ", ".join(f"{k}={v}" for k, v in err.raw.items()))
    return "\n".join(lines) + "\n"


def render_error_log_csv(result: ImportResult) -> str:
    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["row", "reason", *FIELDS])
    for err in result.errors:
        writer.writerow([err.row, err.reason, *[err.raw.get(f, "") for f in FIELDS]])
    return buffer.getvalue()


def write_error_log(result: ImportResult, out_dir) -> Path:
    out_dir = Path(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    path = out_dir / f"import_errors_{time.strftime('%Y%m%d-%H%M%S')}.txt"
    path.write_text(render_error_log_text(result), encoding="utf-8")
    return path
