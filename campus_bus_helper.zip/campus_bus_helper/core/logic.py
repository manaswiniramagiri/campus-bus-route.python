"""Business logic: store routes and stops, search routes by stop name, filter, next bus."""
from __future__ import annotations

import difflib
from dataclasses import dataclass
from pathlib import Path

from .models import (FIELDS, SERVICE_END, Entry, group_routes, route_sort_key, to_hhmm,
                     to_minutes)
from .storage import Storage
from .validation import ValidationError, clean, validate_entry

DEFAULT_DATA = Path(__file__).resolve().parent.parent / "data" / "routes.json"


@dataclass
class StopMatch:
    """A stop name plus every route that serves it."""
    name: str
    entries: list

    @property
    def category(self) -> str:
        return self.entries[0].category


def next_arrival(entry: Entry, now_min: int):
    """Minutes-of-day of the next bus at this stop, or None (suspended / last bus gone)."""
    if entry.status == "Suspended":
        return None
    first = entry.first_minutes
    last = max(to_minutes(SERVICE_END), first)
    if now_min <= first:
        return first
    steps = -(-(now_min - first) // entry.frequency_min)  # ceiling division
    arrival = first + steps * entry.frequency_min
    return arrival if arrival <= last else None


def describe_next(entry: Entry, now_min: int) -> str:
    if entry.status == "Suspended":
        return "Suspended"
    arrival = next_arrival(entry, now_min)
    if arrival is None:
        return "No more buses today"
    wait = arrival - now_min
    if wait == 0:
        phrase = "now"
    elif wait < 60:
        phrase = f"in {wait} min"
    else:
        phrase = f"in {wait // 60} h {wait % 60:02d} min"
    return f"{to_hhmm(arrival)} ({phrase})"


def _raise(errors: dict):
    raise ValidationError(" ".join(errors.values()), errors)


class RouteBook:
    """All records, kept in sync with the JSON file on every change."""

    def __init__(self, path=DEFAULT_DATA):
        self.store = Storage(path)
        self.entries, self.notes = self.store.load()

    # ---------- persistence ----------
    def save(self) -> None:
        self.entries.sort(key=lambda e: (route_sort_key(e.route_id), e.stop_order))
        self.store.save(self.entries)

    def clear(self) -> None:
        self.entries = []
        self.save()

    # ---------- reading ----------
    def get(self, route_id: str, stop_order: int):
        return next((e for e in self.entries if e.key == (route_id, stop_order)), None)

    def routes(self) -> dict:
        return group_routes(self.entries)

    def _conflicts(self, entry: Entry, ignore=None, check_name: bool = True) -> dict:
        errors = {}
        for other in self.entries:
            if other is ignore or other.route_id != entry.route_id:
                continue
            same_order = other.stop_order == entry.stop_order
            same_name = other.stop_name.lower() == entry.stop_name.lower()
            if same_order and same_name:
                errors["stop_name"] = f"{other.stop_name} is already stop {other.stop_order} on {entry.route_id}."
            elif same_order:
                errors["stop_order"] = (f"Stop {entry.stop_order} on {entry.route_id} "
                                        f"is already {other.stop_name}.")
            elif same_name:
                errors["stop_name"] = (f"{other.stop_name} is already on {entry.route_id} "
                                       f"(stop {other.stop_order}).")
            if check_name and other.route_name.lower() != entry.route_name.lower():
                errors["route_name"] = (f"{entry.route_id} is already named "
                                        f"\"{other.route_name}\". Use that name or a new route ID.")
        return errors

    # ---------- writing ----------
    def add(self, raw: dict, save: bool = True) -> Entry:
        entry, errors = validate_entry(raw)
        if errors:
            _raise(errors)
        errors = self._conflicts(entry)
        if errors:
            _raise(errors)
        self.entries.append(entry)
        if save:
            self.save()
        return entry

    def update(self, route_id: str, stop_order: int, changes: dict) -> Entry:
        current = self.get(route_id, stop_order)
        if current is None:
            _raise({"stop_order": f"There is no stop {stop_order} on {route_id}."})
        entry, errors = validate_entry({**current.to_dict(), **changes})
        if errors:
            _raise(errors)
        renaming = entry.route_id == current.route_id and entry.route_name != current.route_name
        errors = self._conflicts(entry, ignore=current, check_name=not renaming)
        if errors:
            _raise(errors)
        if renaming:  # a route has one name, so rename every stop on it
            for other in self.entries:
                if other.route_id == current.route_id:
                    other.route_name = entry.route_name
        for field in FIELDS:
            setattr(current, field, getattr(entry, field))
        self.save()
        return current

    def delete(self, route_id: str, stop_order: int) -> Entry:
        current = self.get(route_id, stop_order)
        if current is None:
            _raise({"stop_order": f"There is no stop {stop_order} on {route_id}."})
        self.entries.remove(current)
        self.save()
        return current

    # ---------- search ----------
    def search_stops(self, query: str) -> list:
        """Partial, case-insensitive match on stop name; one StopMatch per stop."""
        q = clean(query).lower()
        if not q:
            return []
        groups: dict = {}
        for e in self.entries:
            if q in e.stop_name.lower():
                groups.setdefault(e.stop_name.lower(), []).append(e)

        def rank(name):
            return (0 if name == q else 1 if name.startswith(q) else 2, name)

        matches = []
        for name in sorted(groups, key=rank):
            stops = sorted(groups[name], key=lambda e: (route_sort_key(e.route_id), e.stop_order))
            matches.append(StopMatch(stops[0].stop_name, stops))
        return matches

    def suggest_stops(self, query: str, limit: int = 3) -> list:
        names = {e.stop_name.lower(): e.stop_name for e in self.entries}
        close = difflib.get_close_matches(clean(query).lower(), list(names), n=limit, cutoff=0.6)
        return [names[c] for c in close]

    def filter_entries(self, keyword=None, category=None, status=None, route_id=None) -> list:
        def as_set(value):
            if not value:
                return None
            return {value.lower()} if isinstance(value, str) else {v.lower() for v in value}

        categories, statuses = as_set(category), as_set(status)
        keyword = clean(keyword).lower()
        route_id = clean(route_id).upper()
        found = []
        for e in self.entries:
            if categories and e.category.lower() not in categories:
                continue
            if statuses and e.status.lower() not in statuses:
                continue
            if route_id and e.route_id != route_id:
                continue
            if keyword and keyword not in f"{e.route_id} {e.route_name} {e.stop_name}".lower():
                continue
            found.append(e)
        return found
