"""Data model and shared constants."""
from __future__ import annotations

import re
from dataclasses import asdict, dataclass

STATUSES = ("Active", "Delayed", "Suspended")
CATEGORIES = ("Hostel", "Academic", "Admin", "Sports", "Gate")
FIELDS = (
    "route_id", "route_name", "stop_name", "stop_order",
    "arrival_time", "frequency_min", "capacity", "status", "category",
)

FREQ_RANGE = (1, 120)      # minutes between buses
CAP_RANGE = (1, 200)       # seats per bus
ORDER_RANGE = (1, 50)      # position of the stop on its route

SERVICE_START = "05:30"    # earliest sensible first bus
SERVICE_END = "22:00"      # last bus of the day
LONG_WAIT_MIN = 30         # waits above this are flagged
LOW_CAPACITY = 5           # seat counts at or below this are flagged
HIGH_CAPACITY = 150        # seat counts at or above this are noted


def to_minutes(hhmm: str) -> int:
    hours, minutes = hhmm.split(":")
    return int(hours) * 60 + int(minutes)


def to_hhmm(minutes: int) -> str:
    return f"{(minutes // 60) % 24:02d}:{minutes % 60:02d}"


def route_sort_key(route_id: str):
    match = re.match(r"([A-Z]+)(\d+)$", route_id)
    return (match.group(1), int(match.group(2))) if match else (route_id, 0)


@dataclass
class Entry:
    """One stop on one route."""
    route_id: str
    route_name: str
    stop_name: str
    stop_order: int
    arrival_time: str       # HH:MM, first bus at this stop
    frequency_min: int      # minutes between buses
    capacity: int           # seats per bus
    status: str = "Active"
    category: str = "Academic"

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def key(self) -> tuple:
        return (self.route_id, self.stop_order)

    @property
    def first_minutes(self) -> int:
        return to_minutes(self.arrival_time)


def group_routes(entries) -> dict:
    """route_id -> stops in order, with routes in natural order (R2 before R10)."""
    grouped: dict = {}
    for e in sorted(entries, key=lambda e: (route_sort_key(e.route_id), e.stop_order)):
        grouped.setdefault(e.route_id, []).append(e)
    return grouped


def worst_status(entries) -> str:
    present = {e.status for e in entries}
    for status in ("Suspended", "Delayed", "Active"):
        if status in present:
            return status
    return "Active"
