"""JSON persistence with corruption recovery and atomic saves."""
from __future__ import annotations

import json
import os
import shutil
import time
from pathlib import Path

from .models import Entry
from .validation import validate_entry

SCHEMA_VERSION = 1


class Storage:
    def __init__(self, path):
        self.path = Path(path)

    def save(self, entries) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        payload = {"schema_version": SCHEMA_VERSION, "entries": [e.to_dict() for e in entries]}
        tmp = self.path.with_name(self.path.name + ".tmp")
        tmp.write_text(json.dumps(payload, indent=2, ensure_ascii=False), encoding="utf-8")
        os.replace(tmp, self.path)  # a crash mid-write never leaves a half-written file

    def _backup(self) -> Path:
        stamp = time.strftime("%Y%m%d-%H%M%S")
        dest = self.path.with_name(f"{self.path.stem}.corrupt-{stamp}.bak")
        shutil.copy2(self.path, dest)
        return dest

    def load(self) -> tuple[list[Entry], list[str]]:
        """Return (entries, notes). Never raises for a missing or damaged file."""
        data, problem = None, None
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            self.save([])
            return [], [f"No data file found, so a clean one was created ({self.path.name})."]
        except (json.JSONDecodeError, UnicodeDecodeError) as exc:
            problem = f"{type(exc).__name__}"

        raw_entries = None
        if problem is None:
            raw_entries = data.get("entries") if isinstance(data, dict) else data
            if not isinstance(raw_entries, list):
                problem = "unexpected structure"

        if problem:
            backup = self._backup()
            self.save([])
            return [], [f"The data file couldn't be read ({problem}). A copy was kept as "
                        f"{backup.name} and a clean file was started."]

        entries, dropped, seen = [], 0, set()
        for item in raw_entries:
            entry, errors = (validate_entry(item) if isinstance(item, dict) else (None, True))
            if errors:
                dropped += 1
                continue
            keys = {("order", entry.route_id, entry.stop_order),
                    ("name", entry.route_id, entry.stop_name.lower())}
            if keys & seen:
                dropped += 1
                continue
            seen |= keys
            entries.append(entry)

        notes = []
        if dropped:
            backup = self._backup()
            self.save(entries)
            notes.append(f"{dropped} invalid or duplicate record(s) were removed on load. "
                         f"The original file was kept as {backup.name}.")
        return entries, notes
