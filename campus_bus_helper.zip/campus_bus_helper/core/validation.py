"""Validators (shared by CLI, GUI and importer) and the CLI prompt loop."""
from __future__ import annotations

import re
import string
from typing import Callable, Mapping

from .models import (CAP_RANGE, CATEGORIES, FREQ_RANGE, ORDER_RANGE, STATUSES, Entry)


class ValidationError(ValueError):
    """Raised with a plain-language message; `errors` maps field -> message."""

    def __init__(self, message: str, errors: dict | None = None):
        super().__init__(message)
        self.errors = errors or {}


_ROUTE_ID = re.compile(r"^[A-Z]{1,2}\d{1,3}$")
_NAME = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 &'.,()/-]*$")
_TIME = re.compile(r"^([01]?\d|2[0-3]):([0-5]\d)$")
_INT = re.compile(r"^-?\d+$")


def clean(value) -> str:
    """Trim and collapse whitespace; None becomes an empty string."""
    return "" if value is None else " ".join(str(value).split())


def v_route_id(value) -> str:
    text = clean(value).upper().replace(" ", "")
    if not text:
        raise ValidationError("Route ID can't be blank.")
    if not _ROUTE_ID.match(text):
        raise ValidationError("Route ID needs 1-2 letters then 1-3 digits, like R5 or EX12.")
    return text


def _name(value, label: str, lo: int, hi: int) -> str:
    text = clean(value)
    if not text:
        raise ValidationError(f"{label} can't be blank.")
    if not lo <= len(text) <= hi:
        raise ValidationError(f"{label} must be {lo}-{hi} characters (got {len(text)}).")
    if not _NAME.match(text):
        raise ValidationError(f"{label} can use letters, numbers, spaces and & ' . , ( ) / - only.")
    if text.islower() or (text.isupper() and len(text) > 4):
        text = string.capwords(text)
    return text


def v_route_name(value) -> str:
    return _name(value, "Route name", 3, 40)


def v_stop_name(value) -> str:
    return _name(value, "Stop name", 2, 40)


def v_int(value, label: str, lo: int, hi: int) -> int:
    if isinstance(value, float) and value.is_integer():
        value = int(value)
    text = clean(value)
    if not text:
        raise ValidationError(f"{label} can't be blank.")
    if not _INT.match(text):
        raise ValidationError(f"{label} must be a whole number (got '{text}').")
    number = int(text)
    if not lo <= number <= hi:
        raise ValidationError(f"{label} must be between {lo} and {hi} (got {number}).")
    return number


def v_order(value) -> int:
    return v_int(value, "Stop number", *ORDER_RANGE)


def v_frequency(value) -> int:
    return v_int(value, "Minutes between buses", *FREQ_RANGE)


def v_capacity(value) -> int:
    return v_int(value, "Seats per bus", *CAP_RANGE)


def v_time(value) -> str:
    text = clean(value)
    if not text:
        raise ValidationError("Time can't be blank. Use 24-hour HH:MM, like 07:30.")
    match = _TIME.match(text)
    if not match:
        raise ValidationError(f"'{text}' isn't a valid time. Use 24-hour HH:MM, like 07:30.")
    return f"{int(match.group(1)):02d}:{match.group(2)}"


def make_choice_validator(options, label: str) -> Callable:
    def validate(value) -> str:
        text = clean(value)
        if not text:
            raise ValidationError(f"{label} can't be blank.")
        if text.isdigit() and 1 <= int(text) <= len(options):
            return options[int(text) - 1]
        for option in options:
            if option.lower() == text.lower():
                return option
        raise ValidationError(f"{label} must be one of: {', '.join(options)}.")
    return validate


v_status = make_choice_validator(STATUSES, "Status")
v_category = make_choice_validator(CATEGORIES, "Category")

VALIDATORS = {
    "route_id": v_route_id,
    "route_name": v_route_name,
    "stop_name": v_stop_name,
    "stop_order": v_order,
    "arrival_time": v_time,
    "frequency_min": v_frequency,
    "capacity": v_capacity,
    "status": v_status,
    "category": v_category,
}


def validate_entry(raw: Mapping) -> tuple[Entry | None, dict]:
    """Validate every field; return (Entry, {}) or (None, {field: message})."""
    cleaned, errors = {}, {}
    for name, validator in VALIDATORS.items():
        try:
            cleaned[name] = validator(raw.get(name))
        except ValidationError as exc:
            errors[name] = str(exc)
    if errors:
        return None, errors
    return Entry(**cleaned), {}


def prompt_until_valid(prompt, validator, default=None, input_fn=input, on_error=print):
    """Centralised input wrapper: loops until the validator accepts the answer."""
    suffix = f" [{default}]" if default not in (None, "") else ""
    while True:
        raw = input_fn(f"{prompt}{suffix}: ")
        if clean(raw) == "" and default not in (None, ""):
            raw = str(default)
        try:
            return validator(raw)
        except ValidationError as exc:
            on_error(str(exc))
