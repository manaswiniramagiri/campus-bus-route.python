"""Campus Bus Route Helper: Streamlit interface.

Run:  pip install streamlit
      streamlit run gui_streamlit.py
"""
from __future__ import annotations

import html
from datetime import datetime
from pathlib import Path

import pandas as pd
import streamlit as st

from core import analytics, exporter, importer
from core.logic import RouteBook, describe_next
from core.models import CATEGORIES, FIELDS, STATUSES, group_routes, worst_status
from core.validation import ValidationError

BASE = Path(__file__).resolve().parent
DATA_FILE = BASE / "data" / "routes.json"
EXPORT_DIR = BASE / "exports"
SAMPLE_CSV = BASE / "data" / "sample_routes.csv"
SAMPLE_BAD_CSV = BASE / "data" / "sample_import_with_errors.csv"

INK, TEAL, AMBER, RED, MUTED = "#1B2A41", "#0E8C7F", "#F4B400", "#D1495B", "#5B6B7F"
STATUS_COLOR = {"Active": TEAL, "Delayed": AMBER, "Suspended": RED}
LEVEL_COLOR = {"critical": RED, "warning": AMBER, "info": "#3566C9"}
ROUTE_COLORS = ["#0E8C7F", "#D9731A", "#3566C9", "#B03A75", "#6F8F1E", "#7048A8", "#A67C00", "#4F6D7A"]

PAGES = ["Dashboard", "Find a bus", "Add a stop", "Manage stops", "Import CSV", "Export reports"]

st.set_page_config(page_title="Campus Bus Route Helper", page_icon="🚌", layout="wide")

CSS = """
<style>
@import url('https://fonts.googleapis.com/css2?family=Bricolage+Grotesque:opsz,wght@12..96,500;12..96,700&family=Public+Sans:wght@400;500;600&display=swap');
.stApp, .stApp p, .stApp label, .stApp li, .stApp button, .stApp input, .stApp textarea { font-family: 'Public Sans', system-ui, sans-serif; }
.stApp h1, .stApp h2, .stApp h3, [data-testid="stMetricValue"], .brand { font-family: 'Bricolage Grotesque', 'Public Sans', sans-serif; letter-spacing: -0.02em; }
.block-container { padding-top: 2.4rem; max-width: 1180px; }
[data-testid="stMetricLabel"] { color: #5B6B7F; }
[data-testid="stMetricValue"] { font-weight: 700; }
.brand { font-size: 1.5rem; font-weight: 700; color: #1B2A41; margin: .2rem 0 .1rem 0; }
.brand-line { display: flex; align-items: center; margin: .2rem 0 1rem 0; }
.brand-line i { width: 12px; height: 12px; border-radius: 50%; background: #fff; border: 3px solid #0E8C7F; box-sizing: border-box; }
.brand-line b { flex: 0 0 22px; height: 4px; background: #0E8C7F; }
.route { margin: 0 0 1.5rem 0; }
.route-head { display: flex; align-items: center; gap: .6rem; margin-bottom: .3rem; flex-wrap: wrap; }
.badge { color: #fff; font-family: 'Bricolage Grotesque', sans-serif; font-weight: 700; padding: .05rem .65rem; border-radius: 999px; font-size: .95rem; }
.rname { font-weight: 600; color: #1B2A41; }
.rstate { font-size: .85rem; font-weight: 500; }
.line { display: flex; overflow-x: auto; padding: .2rem 0 .5rem 0; }
.stop { flex: 0 0 150px; position: relative; padding-top: 32px; }
.stop::before { content: ""; position: absolute; top: 10px; left: 0; right: 0; height: 6px; background: var(--c); }
.stop:last-child::before { right: auto; width: 13px; }
.stop.s-Suspended::before { background: repeating-linear-gradient(90deg, var(--c) 0 9px, transparent 9px 15px); }
.dot { position: absolute; top: 0; left: 0; width: 26px; height: 26px; border-radius: 50%; background: #fff; border: 6px solid var(--c); box-sizing: border-box; }
.s-Delayed .dot { background: #F4B400; }
.s-Suspended .dot { background: #D1495B; }
.stext { padding-right: .7rem; }
.sname { font-weight: 600; font-size: .92rem; line-height: 1.2; color: #1B2A41; }
.stime { font-size: .8rem; color: #5B6B7F; }
.hit .sname { background: #FFE9A6; border-radius: 4px; padding: 0 .25rem; margin-left: -.25rem; }
.statusbar { display: flex; height: 14px; border-radius: 7px; overflow: hidden; margin: .4rem 0 .5rem 0; }
.legend { font-size: .9rem; color: #5B6B7F; }
.legend span { margin-right: 1.1rem; white-space: nowrap; }
.legend i { display: inline-block; width: 10px; height: 10px; border-radius: 50%; margin-right: .35rem; }
.alert { display: flex; align-items: baseline; gap: .6rem; padding: .3rem 0; border-bottom: 1px solid #DCE5E3; }
.alert i { flex: 0 0 10px; height: 10px; border-radius: 50%; }
@media (prefers-reduced-motion: no-preference) { .stop .dot { transition: transform .15s ease; } .stop:hover .dot { transform: scale(1.12); } }
</style>
"""
st.markdown(CSS, unsafe_allow_html=True)


# ------------------------------------------------------------ helpers
def esc(value) -> str:
    return html.escape(str(value))


def route_color(route_id: str, all_routes) -> str:
    return ROUTE_COLORS[list(all_routes).index(route_id) % len(ROUTE_COLORS)]


def route_strip(route_id: str, stops, color: str, highlight: str = "") -> str:
    """The route drawn as a transit line: one dot per stop, in order."""
    status = worst_status(stops)
    parts = [f'<div class="route"><div class="route-head"><span class="badge" style="background:{color}">'
             f'{esc(route_id)}</span><span class="rname">{esc(stops[0].route_name)}</span>'
             f'<span class="rstate" style="color:{STATUS_COLOR[status]}">{esc(status)}</span></div>'
             f'<div class="line" style="--c:{color}">']
    for e in stops:
        hit = " hit" if highlight and e.stop_name.lower() == highlight.lower() else ""
        parts.append(f'<div class="stop s-{e.status}{hit}"><span class="dot"></span><div class="stext">'
                     f'<div class="sname">{esc(e.stop_name)}</div>'
                     f'<div class="stime">{esc(e.arrival_time)}</div>'
                     f'<div class="stime">every {e.frequency_min} min</div></div></div>')
    parts.append("</div></div>")
    return "".join(parts)


def entries_df(entries) -> pd.DataFrame:
    return pd.DataFrame([{
        "Route": e.route_id, "Route name": e.route_name, "Stop #": e.stop_order, "Stop": e.stop_name,
        "Type": e.category, "First bus": e.arrival_time, "Every (min)": e.frequency_min,
        "Seats": e.capacity, "Status": e.status} for e in entries])


def flash():
    kind, message = st.session_state.pop("flash", (None, None))
    if kind:
        getattr(st, kind)(message)


def show_validation(exc: ValidationError):
    for message in (exc.errors.values() if exc.errors else [str(exc)]):
        st.error(message)
    st.caption("Nothing was saved.")


# ------------------------------------------------------------ pages
def page_dashboard(book: RouteBook):
    st.title("Campus Bus Route Helper")
    flash()
    s = analytics.summarize(book.entries)
    if s["empty"]:
        st.info("No routes yet. Add a stop, or load the sample campus network to explore.")
        if st.button("Load sample data", type="primary"):
            result = importer.import_csv_file(book, SAMPLE_CSV)
            st.session_state["flash"] = ("success", f"Loaded {result.imported} sample stop records.")
            st.rerun()
        return
    alerts = analytics.warnings(book.entries)
    flagged = sum(a.level != "info" for a in alerts)
    st.write(f"{s['total_routes']} routes serve {s['unique_stops']} stops. "
             f"{flagged} warning{'s' if flagged != 1 else ''} to look at.")

    cols = st.columns(5)
    cols[0].metric("Routes", s["total_routes"])
    cols[1].metric("Stops", s["unique_stops"])
    cols[2].metric("Average wait", f"{s['avg_frequency']} min")
    cols[3].metric("Seats per bus", s["avg_capacity"])
    cols[4].metric("Running normally", f"{s['active_pct']}%")

    st.subheader("Route lines")
    routes = book.routes()
    st.markdown("".join(route_strip(rid, stops, route_color(rid, routes)) for rid, stops in routes.items()),
                unsafe_allow_html=True)

    left, right = st.columns(2)
    with left:
        st.subheader("Buses per hour")
        st.bar_chart(pd.Series(s["buses_per_hour"], name="Bus arrivals"), color=TEAL)
    with right:
        st.subheader("Average wait by stop type")
        st.bar_chart(pd.Series(s["avg_frequency_by_category"], name="Minutes"), color="#3566C9")

    st.subheader("Status of stop records")
    counts, total = s["status_counts"], s["total_entries"]
    bar = "".join(f'<div style="flex:{n};background:{STATUS_COLOR[k]}"></div>' for k, n in counts.items() if n)
    legend = "".join(f'<span><i style="background:{STATUS_COLOR[k]}"></i>{k} {n}</span>' for k, n in counts.items())
    st.markdown(f'<div class="statusbar">{bar}</div><div class="legend">{legend}</div>', unsafe_allow_html=True)

    st.subheader("What the data says")
    for line in s["trends"]:
        st.write("- " + line)

    st.subheader("Warnings")
    if not alerts:
        st.success("All clear. Nothing is over a threshold.")
    else:
        def row(a):
            return f'<div class="alert"><i style="background:{LEVEL_COLOR[a.level]}"></i><span>{esc(a.message)}</span></div>'
        st.markdown("".join(row(a) for a in alerts[:8]), unsafe_allow_html=True)
        if len(alerts) > 8:
            with st.expander(f"Show the other {len(alerts) - 8}"):
                st.markdown("".join(row(a) for a in alerts[8:]), unsafe_allow_html=True)


def page_find(book: RouteBook):
    st.title("Find a bus")
    if "leave_at" not in st.session_state:
        st.session_state["leave_at"] = datetime.now().time().replace(second=0, microsecond=0)
    by_stop, browse = st.tabs(["By stop name", "Browse all records"])

    with by_stop:
        c1, c2 = st.columns([3, 1])
        query = c1.text_input("Stop name", placeholder="Try library, gate or hostel")
        leave = c2.time_input("Leaving at", key="leave_at")
        now = leave.hour * 60 + leave.minute
        if not query.strip():
            st.caption("Part of a name is fine, and capital letters don't matter.")
        else:
            matches = book.search_stops(query)
            if not matches:
                st.warning(f"No stop matches \"{query}\".")
                close = book.suggest_stops(query)
                if close:
                    st.write("Did you mean: " + ", ".join(close) + "?")
            routes = book.routes()
            for match in matches:
                st.subheader(match.name)
                st.caption(f"{match.category} stop, served by {len(match.entries)} route"
                           f"{'s' if len(match.entries) != 1 else ''}")
                st.dataframe(pd.DataFrame([{
                    "Route": e.route_id, "Route name": e.route_name, "Stop #": e.stop_order,
                    "Next bus": describe_next(e, now), "Every (min)": e.frequency_min,
                    "Status": e.status} for e in match.entries]), hide_index=True)
                st.markdown("".join(
                    route_strip(e.route_id, routes[e.route_id], route_color(e.route_id, routes), match.name)
                    for e in match.entries), unsafe_allow_html=True)

    with browse:
        c1, c2, c3, c4 = st.columns([2, 2, 2, 1])
        keyword = c1.text_input("Keyword", placeholder="Route or stop", key="kw")
        cats = c2.multiselect("Stop type", CATEGORIES)
        stats = c3.multiselect("Status", STATUSES)
        rid = c4.selectbox("Route", ["All", *book.routes()])
        rows = book.filter_entries(keyword, cats, stats, None if rid == "All" else rid)
        st.caption(f"{len(rows)} of {len(book.entries)} records")
        if rows:
            st.dataframe(entries_df(rows), hide_index=True)
        else:
            st.info("Nothing matches those filters. Clear one to see more.")


def page_add(book: RouteBook):
    st.title("Add a stop")
    flash()
    st.write("Each record is one stop on one route. Use the same route ID and name to build a route up stop by stop.")
    if book.entries:
        st.caption("Existing routes: " + ", ".join(f"{rid} ({stops[0].route_name})" for rid, stops in book.routes().items()))
    with st.form("add_stop"):
        a, b = st.columns(2)
        route_id = a.text_input("Route ID", placeholder="R5")
        route_name = b.text_input("Route name", placeholder="Hostel Loop")
        stop_name = a.text_input("Stop name", placeholder="Library")
        stop_order = b.number_input("Stop number on the route", min_value=1, max_value=50, value=1, step=1)
        arrival = a.text_input("First bus at this stop (HH:MM)", placeholder="07:30")
        freq = b.number_input("Minutes between buses", min_value=1, max_value=120, value=15, step=1)
        cap = a.number_input("Seats per bus", min_value=1, max_value=200, value=40, step=1)
        status = b.selectbox("Status", STATUSES)
        category = a.selectbox("Stop type", CATEGORIES)
        submitted = st.form_submit_button("Save stop", type="primary")
    if submitted:
        try:
            entry = book.add(dict(route_id=route_id, route_name=route_name, stop_name=stop_name,
                                  stop_order=stop_order, arrival_time=arrival, frequency_min=freq,
                                  capacity=cap, status=status, category=category))
        except ValidationError as exc:
            show_validation(exc)
        else:
            st.success(f"Saved {entry.stop_name} as stop {entry.stop_order} on {entry.route_id}.")
            st.toast("Stop saved")


def page_manage(book: RouteBook):
    st.title("Manage stops")
    flash()
    if not book.entries:
        st.info("No stops to manage yet.")
        return
    labels = {f"{e.route_id}, stop {e.stop_order}: {e.stop_name}": e for e in book.entries}
    entry = labels[st.selectbox("Choose a stop", list(labels))]
    k = f"{entry.route_id}_{entry.stop_order}"
    with st.form(f"edit_{k}"):
        a, b = st.columns(2)
        route_name = a.text_input("Route name", entry.route_name, key=f"rn_{k}")
        stop_name = b.text_input("Stop name", entry.stop_name, key=f"sn_{k}")
        stop_order = a.number_input("Stop number", 1, 50, entry.stop_order, key=f"so_{k}")
        arrival = b.text_input("First bus (HH:MM)", entry.arrival_time, key=f"at_{k}")
        freq = a.number_input("Minutes between buses", 1, 120, entry.frequency_min, key=f"fq_{k}")
        cap = b.number_input("Seats per bus", 1, 200, entry.capacity, key=f"cp_{k}")
        status = a.selectbox("Status", STATUSES, index=STATUSES.index(entry.status), key=f"st_{k}")
        category = b.selectbox("Stop type", CATEGORIES, index=CATEGORIES.index(entry.category), key=f"ct_{k}")
        confirm = st.checkbox("I want to delete this stop", key=f"cf_{k}")
        save, delete = st.columns([1, 1])
        do_save = save.form_submit_button("Save changes", type="primary")
        do_delete = delete.form_submit_button("Delete stop")
    if do_save:
        try:
            book.update(entry.route_id, entry.stop_order, dict(
                route_name=route_name, stop_name=stop_name, stop_order=stop_order, arrival_time=arrival,
                frequency_min=freq, capacity=cap, status=status, category=category))
        except ValidationError as exc:
            show_validation(exc)
        else:
            st.session_state["flash"] = ("success", "Changes saved.")
            st.rerun()
    if do_delete:
        if confirm:
            book.delete(entry.route_id, entry.stop_order)
            st.session_state["flash"] = ("success", f"Deleted {entry.stop_name} from {entry.route_id}.")
            st.rerun()
        else:
            st.warning("Tick \"I want to delete this stop\" first, then press Delete stop.")


def page_import(book: RouteBook):
    st.title("Import CSV")
    flash()
    st.write("Add many stops at once. Every row is checked, and rejected rows are listed with the reason.")
    with st.expander("Columns the file needs"):
        st.code(",".join(FIELDS))
        st.download_button("Download a template", ",".join(FIELDS) + "\n", "bus_routes_template.csv", "text/csv")
    upload = st.file_uploader("Choose a CSV file", type="csv")
    a, b, c = st.columns(3)
    result = None
    if a.button("Import file", type="primary", disabled=upload is None):
        text = upload.getvalue().decode("utf-8-sig", errors="replace")
        result = importer.import_csv_text(book, text, upload.name)
    if b.button("Try the messy demo file"):
        result = importer.import_csv_file(book, SAMPLE_BAD_CSV)
    if c.button("Add the sample network"):
        result = importer.import_csv_file(book, SAMPLE_CSV)
    if result is not None:
        st.session_state["import_result"] = result
    result = st.session_state.get("import_result")
    if result is None:
        return
    if result.fatal:
        st.error(result.fatal)
        return
    m = st.columns(3)
    m[0].metric("Rows read", result.total)
    m[1].metric("Imported", result.imported)
    m[2].metric("Rejected", result.rejected)
    if result.errors:
        st.warning(f"{result.rejected} row(s) were rejected. Fix them in the file and import again.")
        st.dataframe(pd.DataFrame([{"Row": e.row, "Why it was rejected": e.reason} for e in result.errors]),
                     hide_index=True)
        st.download_button("Download error log", importer.render_error_log_csv(result),
                           "import_errors.csv", "text/csv")
    else:
        st.success("Every row was imported.")


def page_export(book: RouteBook):
    st.title("Export reports")
    if not book.entries:
        st.info("Nothing to export yet.")
        return
    md = exporter.render_markdown(book.entries)
    audit = exporter.render_audit_log(book.entries)
    report = exporter.render_csv_report(book.entries)
    records = exporter.render_records_csv(book.entries)
    a, b, c, d = st.columns(4)
    a.download_button("Markdown summary", md, "service_summary.md", "text/markdown")
    b.download_button("Audit log", audit, "audit_log.txt", "text/plain")
    c.download_button("Route report (CSV)", report, "route_report.csv", "text/csv")
    d.download_button("All records (CSV)", records, "records.csv", "text/csv")
    if st.button("Also save copies in the exports folder"):
        paths = exporter.export_all(book.entries, EXPORT_DIR)
        st.success("Saved: " + ", ".join(p.name for p in paths.values()))
    with st.expander("Preview the Markdown summary", expanded=True):
        st.markdown(md)
    with st.expander("Preview the audit log"):
        st.code(audit)


# ------------------------------------------------------------ app shell
def main():
    book = RouteBook(DATA_FILE)  # reloaded every run, so the file is always the source of truth
    with st.sidebar:
        st.markdown('<div class="brand">Campus Bus</div><div class="brand-line"><i></i><b></b><i></i><b></b><i></i></div>',
                    unsafe_allow_html=True)
        page = st.radio("Go to", PAGES, label_visibility="collapsed")
        st.caption(f"{len(book.entries)} stop records saved in data/{DATA_FILE.name}")
        for note in book.notes:
            st.warning(note)
    {"Dashboard": page_dashboard, "Find a bus": page_find, "Add a stop": page_add,
     "Manage stops": page_manage, "Import CSV": page_import, "Export reports": page_export}[page](book)


main()
