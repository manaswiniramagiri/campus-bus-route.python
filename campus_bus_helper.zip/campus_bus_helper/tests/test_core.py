"""Run with:  python -m unittest discover -s tests -v"""
import json
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from core import analytics, exporter, importer
from core import validation as V
from core.logic import RouteBook, describe_next, next_arrival
from core.models import Entry

ROOT = Path(__file__).resolve().parent.parent
GOOD = dict(route_id="R1", route_name="Gate Loop", stop_name="Main Gate", stop_order=1,
            arrival_time="07:00", frequency_min=10, capacity=40, status="Active", category="Gate")


def make_book(tmp):
    return RouteBook(Path(tmp) / "routes.json")


class ValidationTests(unittest.TestCase):
    def test_route_id(self):
        self.assertEqual(V.v_route_id(" r5 "), "R5")
        for bad in ("", "5", "RRR1", "R", "R1234"):
            with self.assertRaises(V.ValidationError):
                V.v_route_id(bad)

    def test_numbers_reject_text_blank_and_out_of_range(self):
        self.assertEqual(V.v_frequency("1"), 1)
        self.assertEqual(V.v_frequency("120"), 120)
        self.assertEqual(V.v_capacity(200), 200)
        for bad in ("0", "121", "abc", "", "3.5", "  "):
            with self.assertRaises(V.ValidationError):
                V.v_frequency(bad)
        with self.assertRaises(V.ValidationError):
            V.v_capacity("201")

    def test_time(self):
        self.assertEqual(V.v_time("8:05"), "08:05")
        for bad in ("25:00", "12:60", "noon", "", "7"):
            with self.assertRaises(V.ValidationError):
                V.v_time(bad)

    def test_names_are_normalised(self):
        self.assertEqual(V.v_stop_name("  main   gate "), "Main Gate")
        with self.assertRaises(V.ValidationError):
            V.v_stop_name("<script>")

    def test_choice_accepts_name_or_number(self):
        self.assertEqual(V.v_status("delayed"), "Delayed")
        self.assertEqual(V.v_status("3"), "Suspended")
        with self.assertRaises(V.ValidationError):
            V.v_status("broken")

    def test_prompt_loop_retries_until_valid(self):
        answers = iter(["", "abc", "999", "25"])
        errors = []
        value = V.prompt_until_valid("n", V.v_frequency, input_fn=lambda _: next(answers),
                                     on_error=errors.append)
        self.assertEqual(value, 25)
        self.assertEqual(len(errors), 3)

    def test_validate_entry_collects_every_error(self):
        entry, errors = V.validate_entry({"route_id": "bad"})
        self.assertIsNone(entry)
        self.assertEqual(set(errors), set(V.VALIDATORS))


class StorageTests(unittest.TestCase):
    def test_missing_file_is_created(self):
        with tempfile.TemporaryDirectory() as tmp:
            book = make_book(tmp)
            self.assertEqual(book.entries, [])
            self.assertTrue((Path(tmp) / "routes.json").exists())
            self.assertTrue(book.notes)

    def test_corrupt_json_is_backed_up_and_reset(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "routes.json").write_text("{not json", encoding="utf-8")
            book = make_book(tmp)
            self.assertEqual(book.entries, [])
            self.assertEqual(len(list(Path(tmp).glob("*.bak"))), 1)

    def test_wrong_structure_is_handled(self):
        with tempfile.TemporaryDirectory() as tmp:
            (Path(tmp) / "routes.json").write_text('{"entries": "oops"}', encoding="utf-8")
            self.assertEqual(make_book(tmp).entries, [])

    def test_invalid_records_dropped_valid_kept(self):
        with tempfile.TemporaryDirectory() as tmp:
            payload = {"entries": [GOOD, {**GOOD, "stop_order": 2, "frequency_min": 0}, "junk"]}
            (Path(tmp) / "routes.json").write_text(json.dumps(payload), encoding="utf-8")
            book = make_book(tmp)
            self.assertEqual(len(book.entries), 1)
            self.assertTrue(list(Path(tmp).glob("*.bak")))

    def test_data_survives_restart(self):
        with tempfile.TemporaryDirectory() as tmp:
            make_book(tmp).add(GOOD)
            again = make_book(tmp)
            self.assertEqual([e.stop_name for e in again.entries], ["Main Gate"])


class LogicTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.book = make_book(self.tmp.name)
        self.book.add(GOOD)
        self.book.add({**GOOD, "stop_name": "Library", "stop_order": 2, "arrival_time": "07:05",
                       "category": "Academic"})
        self.book.add({**GOOD, "route_id": "R2", "route_name": "Hostel Loop", "stop_name": "library",
                       "arrival_time": "08:00", "frequency_min": 20, "category": "Academic"})

    def tearDown(self):
        self.tmp.cleanup()

    def test_search_is_partial_and_case_insensitive(self):
        matches = self.book.search_stops("LIB")
        self.assertEqual(len(matches), 1)
        self.assertEqual(matches[0].name, "Library")
        self.assertEqual({e.route_id for e in matches[0].entries}, {"R1", "R2"})

    def test_search_miss_and_suggestion(self):
        self.assertEqual(self.book.search_stops("zzz"), [])
        self.assertIn("Library", self.book.suggest_stops("libary"))

    def test_duplicates_rejected(self):
        with self.assertRaises(V.ValidationError):
            self.book.add({**GOOD, "stop_name": "Other"})            # same route + stop number
        with self.assertRaises(V.ValidationError):
            self.book.add({**GOOD, "stop_order": 9})                 # same route + stop name
        with self.assertRaises(V.ValidationError):
            self.book.add({**GOOD, "route_name": "Different", "stop_name": "X", "stop_order": 9})

    def test_update_renames_whole_route_and_delete(self):
        self.book.update("R1", 1, {"route_name": "Renamed Loop"})
        self.assertTrue(all(e.route_name == "Renamed Loop" for e in self.book.routes()["R1"]))
        self.book.delete("R1", 2)
        self.assertEqual(len(self.book.routes()["R1"]), 1)
        with self.assertRaises(V.ValidationError):
            self.book.delete("R1", 2)

    def test_filters(self):
        self.assertEqual(len(self.book.filter_entries(category="Academic")), 2)
        self.assertEqual(len(self.book.filter_entries(route_id="r2")), 1)
        self.assertEqual(len(self.book.filter_entries(keyword="hostel")), 1)
        self.assertEqual(len(self.book.filter_entries(status=["Delayed"])), 0)

    def test_next_arrival(self):
        e = Entry("R1", "Gate Loop", "Main Gate", 1, "07:00", 10, 40)
        self.assertEqual(next_arrival(e, 6 * 60), 7 * 60)
        self.assertEqual(next_arrival(e, 7 * 60 + 1), 7 * 60 + 10)
        self.assertEqual(next_arrival(e, 7 * 60 + 10), 7 * 60 + 10)
        self.assertIsNone(next_arrival(e, 22 * 60 + 1))
        e.status = "Suspended"
        self.assertIsNone(next_arrival(e, 6 * 60))
        self.assertEqual(describe_next(e, 0), "Suspended")


class AnalyticsTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.book = make_book(self.tmp.name)
        result = importer.import_csv_file(self.book, ROOT / "data" / "sample_routes.csv")
        self.assertEqual(result.imported, 40)

    def tearDown(self):
        self.tmp.cleanup()

    def test_summary_numbers(self):
        s = analytics.summarize(self.book.entries)
        self.assertEqual((s["total_entries"], s["total_routes"]), (40, 10))
        self.assertEqual(sum(s["status_counts"].values()), 40)
        self.assertEqual(s["busiest_stops"][0][0], "Main Gate")
        self.assertEqual((s["min_frequency"], s["max_frequency"]), (1, 120))

    def test_empty_summary(self):
        self.assertTrue(analytics.summarize([])["empty"])

    def test_warnings_cover_each_threshold(self):
        codes = {a.code for a in analytics.warnings(self.book.entries)}
        self.assertTrue({"SUSPENDED", "DELAYED", "LONG_WAIT", "LOW_CAPACITY", "HIGH_CAPACITY"} <= codes)
        first = analytics.warnings(self.book.entries)[0]
        self.assertEqual(first.level, "critical")

    def test_gap_and_odd_hours(self):
        entries = [Entry("R1", "Gate Loop", "A", 1, "04:00", 10, 40), Entry("R1", "Gate Loop", "B", 3, "04:05", 10, 40)]
        codes = {a.code for a in analytics.warnings(entries)}
        self.assertTrue({"ORDER_GAP", "ODD_HOURS"} <= codes)


class ImportExportTests(unittest.TestCase):
    def test_messy_import_reports_every_bad_row(self):
        with tempfile.TemporaryDirectory() as tmp:
            book = make_book(tmp)
            importer.import_csv_file(book, ROOT / "data" / "sample_routes.csv")
            result = importer.import_csv_file(book, ROOT / "data" / "sample_import_with_errors.csv")
            self.assertEqual((result.imported, result.rejected), (6, 10))
            self.assertTrue(all(e.reason for e in result.errors))
            self.assertEqual(len(make_book(tmp).entries), 46)          # persisted
            log = importer.write_error_log(result, Path(tmp) / "out")
            self.assertIn("Row 8", log.read_text(encoding="utf-8"))
            self.assertIn("reason", importer.render_error_log_csv(result).splitlines()[0])

    def test_bad_files(self):
        with tempfile.TemporaryDirectory() as tmp:
            book = make_book(tmp)
            self.assertTrue(importer.import_csv_text(book, "").fatal)
            self.assertIn("Missing", importer.import_csv_text(book, "a,b\n1,2\n").fatal)
            self.assertTrue(importer.import_csv_file(book, Path(tmp) / "nope.csv").fatal)

    def test_exports_written(self):
        with tempfile.TemporaryDirectory() as tmp:
            book = make_book(tmp)
            importer.import_csv_file(book, ROOT / "data" / "sample_routes.csv")
            paths = exporter.export_all(book.entries, Path(tmp) / "exports")
            self.assertEqual(len(paths), 4)
            self.assertIn("## Warnings", paths["Markdown summary"].read_text(encoding="utf-8"))
            self.assertIn("AUDIT LOG", paths["Audit log"].read_text(encoding="utf-8"))
            self.assertEqual(len(paths["CSV report"].read_text(encoding="utf-8").splitlines()), 11)


if __name__ == "__main__":
    unittest.main()
